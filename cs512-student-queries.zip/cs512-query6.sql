-- Select the first name, last name and film title of all films an actor with the last name Cage acted in.
-- Order by the film title, descending. There should be one row for every actor/film pair.

