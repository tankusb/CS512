-- Delete all rows from bsg_people where the person has no homeword

