-- Insert Anastasia Dualla from Sagittaron into the bsg_people table. You should use a subquery to do this.

