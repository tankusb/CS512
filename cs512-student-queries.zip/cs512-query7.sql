-- Insert Felix Gaeta with an age of 28 into the bsg_people table

