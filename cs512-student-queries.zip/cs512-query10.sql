-- Update the bsg_people table. Set anyone named Gaius Baltar to be from Caprica. This should use a subquery.

