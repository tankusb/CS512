-- Insert Felix Gaeta with an age of 28 into the bsg_people table
INSERT INTO bsg_people (id, fname, lname, homeworld, age)
VALUES (237, 'Felix', 'Gaeta', 'Cylon' , 28)